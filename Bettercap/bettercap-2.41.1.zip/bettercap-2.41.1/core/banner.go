package core

const (
	Name    = "bettercap"
	Version = "2.41.1"
	Author  = "Simone 'evilsocket' Margaritelli"
	Website = "https://bettercap.org/"
)
