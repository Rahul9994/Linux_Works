package network

type DebugFunc func(format string, args ...interface{})

var Debug = func(format string, args ...interface{}) {

}
